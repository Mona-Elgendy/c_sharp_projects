﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManager.Utitlities
{
   public enum ListTypes
    {
City = 1,
District=2,
Gender=3,
EmployeeJobTitle=4,
YesNo=5,
EmployeeReasonLeft=6

    }
}
