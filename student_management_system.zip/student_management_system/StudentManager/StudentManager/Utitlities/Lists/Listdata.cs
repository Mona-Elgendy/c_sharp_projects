﻿using JIDBFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManager.Utitlities.Lists
{
    public class Listdata
    {
public static void LoaddataIntoDataGridView(DataGridView dgv ,string storedProcedureName )
        {
            DBSqlServer db = new DBSqlServer(AppSetting.connectionString());
            dgv.DataSource = db.GetDataList(storedProcedureName);
            dgv.MultiSelect = false;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        public static void LoadDataIntoComboBox(ComboBox cb , DbParameter parameter)
        {
            DBSqlServer db = new DBSqlServer(AppSetting.connectionString());
            cb.DataSource = db.GetDataList("usp_ListTypesDatagetDataByListTypeId", parameter);
            cb.DisplayMember = "Discription";
            cb.ValueMember = "Id";


            cb.SelectedIndex = -1;
            cb.DropDownStyle = ComboBoxStyle.DropDownList;

        }

        public static void LoadDataIntoComboBox(ComboBox cb, string StoredProcedureName)
        {
            DBSqlServer db = new DBSqlServer(AppSetting.connectionString());
            cb.DataSource = db.GetDataList(StoredProcedureName);
            cb.DisplayMember = "Discription";
            cb.ValueMember = "Id";


            cb.SelectedIndex = -1;
            cb.DropDownStyle = ComboBoxStyle.DropDownList;

        }



        public static void LoadDataIntoComboBox(ComboBox cb,string StoredProcedureName  ,DbParameter parameter)
        {
            DBSqlServer db = new DBSqlServer(AppSetting.connectionString());
            cb.DataSource = db.GetDataList(StoredProcedureName, parameter);
            cb.DisplayMember = "Discription";
            cb.ValueMember = "Id";


            cb.SelectedIndex = -1;
            cb.DropDownStyle = ComboBoxStyle.DropDownList;

        }


        public static void LoadDataIntoComboBox(ComboBox cb, string StoredProcedureName, DbParameter[] parameters)
        {
            DBSqlServer db = new DBSqlServer(AppSetting.connectionString());
            cb.DataSource = db.GetDataList(StoredProcedureName, parameters);
            cb.DisplayMember = "Discription";
            cb.ValueMember = "Id";


            cb.SelectedIndex = -1;
            cb.DropDownStyle = ComboBoxStyle.DropDownList;

        }





    }
}
