﻿namespace StudentManager.Screens.Branches
{
    partial class BranchInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BranchInfoForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TopPanel = new System.Windows.Forms.Panel();
            this.DistinctNameComboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.CityNameComboBox = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.PostalCodeTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.AddressLineTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.WebsiteAddressTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.PhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.EmailAddressTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BranchNameTextBox = new System.Windows.Forms.TextBox();
            this.BranchNameLabel = new System.Windows.Forms.Label();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            this.LabelTopPanel = new System.Windows.Forms.Panel();
            this.TopPanelLabel = new System.Windows.Forms.Label();
            this.GetPhotoPictureBox = new System.Windows.Forms.PictureBox();
            this.ClearPictureBox = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.TopPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.LabelTopPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GetPhotoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClearPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem,
            this.toolStripMenuItem1,
            this.saveRecordToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1328, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(57, 24);
            this.closeToolStripMenuItem.Text = "&Close";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(25, 24);
            this.toolStripMenuItem1.Text = "|";
            // 
            // saveRecordToolStripMenuItem
            // 
            this.saveRecordToolStripMenuItem.Name = "saveRecordToolStripMenuItem";
            this.saveRecordToolStripMenuItem.Size = new System.Drawing.Size(103, 24);
            this.saveRecordToolStripMenuItem.Text = "Save Record";
            this.saveRecordToolStripMenuItem.Click += new System.EventHandler(this.saveRecordToolStripMenuItem_Click);
            // 
            // TopPanel
            // 
            this.TopPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TopPanel.Controls.Add(this.GetPhotoPictureBox);
            this.TopPanel.Controls.Add(this.ClearPictureBox);
            this.TopPanel.Controls.Add(this.DistinctNameComboBox);
            this.TopPanel.Controls.Add(this.label9);
            this.TopPanel.Controls.Add(this.CityNameComboBox);
            this.TopPanel.Controls.Add(this.label8);
            this.TopPanel.Controls.Add(this.PostalCodeTextBox);
            this.TopPanel.Controls.Add(this.label7);
            this.TopPanel.Controls.Add(this.AddressLineTextBox);
            this.TopPanel.Controls.Add(this.label6);
            this.TopPanel.Controls.Add(this.WebsiteAddressTextBox);
            this.TopPanel.Controls.Add(this.label5);
            this.TopPanel.Controls.Add(this.PhoneNumberTextBox);
            this.TopPanel.Controls.Add(this.label4);
            this.TopPanel.Controls.Add(this.EmailAddressTextBox);
            this.TopPanel.Controls.Add(this.label3);
            this.TopPanel.Controls.Add(this.BranchNameTextBox);
            this.TopPanel.Controls.Add(this.BranchNameLabel);
            this.TopPanel.Controls.Add(this.LogoPictureBox);
            this.TopPanel.Controls.Add(this.LabelTopPanel);
            this.TopPanel.Location = new System.Drawing.Point(22, 58);
            this.TopPanel.Name = "TopPanel";
            this.TopPanel.Size = new System.Drawing.Size(1082, 600);
            this.TopPanel.TabIndex = 1;
            this.TopPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.TopPanel_Paint);
            // 
            // DistinctNameComboBox
            // 
            this.DistinctNameComboBox.FormattingEnabled = true;
            this.DistinctNameComboBox.Location = new System.Drawing.Point(683, 460);
            this.DistinctNameComboBox.Name = "DistinctNameComboBox";
            this.DistinctNameComboBox.Size = new System.Drawing.Size(179, 28);
            this.DistinctNameComboBox.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(404, 469);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 20);
            this.label9.TabIndex = 15;
            this.label9.Text = "District Name";
            // 
            // CityNameComboBox
            // 
            this.CityNameComboBox.FormattingEnabled = true;
            this.CityNameComboBox.Location = new System.Drawing.Point(683, 416);
            this.CityNameComboBox.Name = "CityNameComboBox";
            this.CityNameComboBox.Size = new System.Drawing.Size(179, 28);
            this.CityNameComboBox.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(404, 425);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 20);
            this.label8.TabIndex = 13;
            this.label8.Text = "City Name";
            // 
            // PostalCodeTextBox
            // 
            this.PostalCodeTextBox.Location = new System.Drawing.Point(683, 501);
            this.PostalCodeTextBox.Name = "PostalCodeTextBox";
            this.PostalCodeTextBox.Size = new System.Drawing.Size(179, 26);
            this.PostalCodeTextBox.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(400, 507);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "Postal Code";
            // 
            // AddressLineTextBox
            // 
            this.AddressLineTextBox.Location = new System.Drawing.Point(683, 373);
            this.AddressLineTextBox.Name = "AddressLineTextBox";
            this.AddressLineTextBox.Size = new System.Drawing.Size(257, 26);
            this.AddressLineTextBox.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(400, 379);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "Address Line";
            // 
            // WebsiteAddressTextBox
            // 
            this.WebsiteAddressTextBox.Location = new System.Drawing.Point(683, 318);
            this.WebsiteAddressTextBox.Name = "WebsiteAddressTextBox";
            this.WebsiteAddressTextBox.Size = new System.Drawing.Size(257, 26);
            this.WebsiteAddressTextBox.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(400, 324);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Website Address";
            // 
            // PhoneNumberTextBox
            // 
            this.PhoneNumberTextBox.Location = new System.Drawing.Point(683, 267);
            this.PhoneNumberTextBox.Name = "PhoneNumberTextBox";
            this.PhoneNumberTextBox.Size = new System.Drawing.Size(257, 26);
            this.PhoneNumberTextBox.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(400, 273);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Phone Number";
            // 
            // EmailAddressTextBox
            // 
            this.EmailAddressTextBox.Location = new System.Drawing.Point(683, 216);
            this.EmailAddressTextBox.Name = "EmailAddressTextBox";
            this.EmailAddressTextBox.Size = new System.Drawing.Size(257, 26);
            this.EmailAddressTextBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(400, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Email Addtress";
            // 
            // BranchNameTextBox
            // 
            this.BranchNameTextBox.Location = new System.Drawing.Point(683, 166);
            this.BranchNameTextBox.Name = "BranchNameTextBox";
            this.BranchNameTextBox.Size = new System.Drawing.Size(257, 26);
            this.BranchNameTextBox.TabIndex = 0;
            this.BranchNameTextBox.TextChanged += new System.EventHandler(this.BranchNameTextBox_TextChanged);
            // 
            // BranchNameLabel
            // 
            this.BranchNameLabel.AutoSize = true;
            this.BranchNameLabel.Location = new System.Drawing.Point(400, 172);
            this.BranchNameLabel.Name = "BranchNameLabel";
            this.BranchNameLabel.Size = new System.Drawing.Size(112, 20);
            this.BranchNameLabel.TabIndex = 1;
            this.BranchNameLabel.Text = "Branch Name";
            this.BranchNameLabel.Click += new System.EventHandler(this.BranchNameLabel_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.BackColor = System.Drawing.Color.White;
            this.LogoPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LogoPictureBox.Location = new System.Drawing.Point(42, 219);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(285, 270);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.LogoPictureBox.TabIndex = 0;
            this.LogoPictureBox.TabStop = false;
            this.LogoPictureBox.Click += new System.EventHandler(this.LogoPictureBox_Click);
            // 
            // LabelTopPanel
            // 
            this.LabelTopPanel.BackColor = System.Drawing.Color.DarkSlateGray;
            this.LabelTopPanel.Controls.Add(this.TopPanelLabel);
            this.LabelTopPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.LabelTopPanel.Location = new System.Drawing.Point(0, 0);
            this.LabelTopPanel.Name = "LabelTopPanel";
            this.LabelTopPanel.Size = new System.Drawing.Size(1080, 136);
            this.LabelTopPanel.TabIndex = 0;
            // 
            // TopPanelLabel
            // 
            this.TopPanelLabel.AutoSize = true;
            this.TopPanelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TopPanelLabel.ForeColor = System.Drawing.Color.White;
            this.TopPanelLabel.Location = new System.Drawing.Point(57, 41);
            this.TopPanelLabel.Name = "TopPanelLabel";
            this.TopPanelLabel.Size = new System.Drawing.Size(419, 36);
            this.TopPanelLabel.TabIndex = 0;
            this.TopPanelLabel.Text = "Pioneer International School";
            // 
            // GetPhotoPictureBox
            // 
            this.GetPhotoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("GetPhotoPictureBox.Image")));
            this.GetPhotoPictureBox.Location = new System.Drawing.Point(117, 518);
            this.GetPhotoPictureBox.Name = "GetPhotoPictureBox";
            this.GetPhotoPictureBox.Size = new System.Drawing.Size(56, 50);
            this.GetPhotoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GetPhotoPictureBox.TabIndex = 32;
            this.GetPhotoPictureBox.TabStop = false;
            this.GetPhotoPictureBox.Click += new System.EventHandler(this.GetPhotoPictureBox_Click);
            // 
            // ClearPictureBox
            // 
            this.ClearPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("ClearPictureBox.Image")));
            this.ClearPictureBox.Location = new System.Drawing.Point(203, 518);
            this.ClearPictureBox.Name = "ClearPictureBox";
            this.ClearPictureBox.Size = new System.Drawing.Size(55, 50);
            this.ClearPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ClearPictureBox.TabIndex = 31;
            this.ClearPictureBox.TabStop = false;
            this.ClearPictureBox.Click += new System.EventHandler(this.ClearPictureBox_Click);
            // 
            // BranchInfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1328, 713);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.TopPanel);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "BranchInfoForm";
            this.Text = "Branch Info Screen";
            this.Load += new System.EventHandler(this.BranchInfoForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.TopPanel.ResumeLayout(false);
            this.TopPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.LabelTopPanel.ResumeLayout(false);
            this.LabelTopPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GetPhotoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClearPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveRecordToolStripMenuItem;
        private System.Windows.Forms.Panel TopPanel;
        private System.Windows.Forms.Panel LabelTopPanel;
        private System.Windows.Forms.PictureBox LogoPictureBox;
        private System.Windows.Forms.Label TopPanelLabel;
        private System.Windows.Forms.TextBox PostalCodeTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox AddressLineTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox WebsiteAddressTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox PhoneNumberTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox EmailAddressTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox BranchNameTextBox;
        private System.Windows.Forms.Label BranchNameLabel;
        private System.Windows.Forms.ComboBox DistinctNameComboBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox CityNameComboBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox GetPhotoPictureBox;
        private System.Windows.Forms.PictureBox ClearPictureBox;
    }
}