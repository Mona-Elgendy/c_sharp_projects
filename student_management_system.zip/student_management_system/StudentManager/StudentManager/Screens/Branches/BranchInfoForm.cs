﻿using JIDBFramework;
using JIDBFramework.Windows;
using StudentManager.Models.Branches;
using StudentManager.Models.Users;
using StudentManager.Screens.Templates;
using StudentManager.Utitlities;
using StudentManager.Utitlities.Lists;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace StudentManager.Screens.Branches
{
    public partial class BranchInfoForm : TemplateForm
    {
        public BranchInfoForm()
        {
            InitializeComponent();
        }

        public int BranchId { get; set; }

        private void BranchNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void BranchNameTextBox_TextChanged(object sender, EventArgs e)
        {
            TopPanelLabel.Text = BranchNameTextBox.Text;
        }

        private void LogoPictureBox_Click(object sender, EventArgs e)
        {
            GetPhoto();

        }

        private void GetPhoto()
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Title = "Please Select the Logo";
            ofd.Filter = "Logo File (*.png;*.jpg;*.bmp;*.gif) |*.png;*.jpg;*.bmp;*.gif";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                LogoPictureBox.Image = new Bitmap(ofd.FileName);
            }
        }

        private void BranchInfoForm_Load(object sender, EventArgs e)
        {
            LoadDataIntoComboBox();
            LoadDataAndBindToControlIfUpdate();
        }

        private void LoadDataIntoComboBox()
        {
            Listdata.LoadDataIntoComboBox(CityNameComboBox, new DbParameter
            {
                Parameter =
                "@ListTypeId",
                Value = ListTypes.City
            });


            Listdata.LoadDataIntoComboBox(DistinctNameComboBox, new DbParameter
            {
                Parameter =
              "@ListTypeId",
                Value = ListTypes.District
            });


        }

        private void LoadDataAndBindToControlIfUpdate()
        {
            if(this.IsUpdate)
            {
                DBSqlServer db = new DBSqlServer(AppSetting.connectionString());

              


                DataTable dtBranch = db.GetDataList("usp_BranchesGetBranchDetailByBrancId", new DbParameter { Parameter="@BranchId" ,Value=BranchId} );
                DataRow row = dtBranch.Rows[0];
                BranchNameTextBox.Text = row["BranchName"].ToString();
                EmailAddressTextBox.Text = row["Email"].ToString();
                PhoneNumberTextBox.Text = row["Telephone"].ToString();
                WebsiteAddressTextBox.Text = row["Website"].ToString();
                LogoPictureBox.Image = (row["BranchImage"] is DBNull)? null : ImageManipulation.PutPhoto((byte[])row["BranchImage"]);
                AddressLineTextBox.Text = row["AddressLine"].ToString();

                CityNameComboBox.SelectedValue = row["CityId"];
                DistinctNameComboBox.SelectedValue = row["DistinctId"];
                PostalCodeTextBox.Text = row["PostalCode"].ToString();
                PostalCodeTextBox.Text = row["PostalCode"].ToString();




            }
        }

        private void saveRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(IsFormValidated())
            {

            if(this.IsUpdate)
            {
                    SaveOrUpdateRecord("usp_BranchesUpdateBranchDetail");
                    JIMessageBox.ShowSuccessMessage("Record Is Updated Successfully");
                    // MessageBox.Show("Record Is Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            else
            {
                    SaveOrUpdateRecord("usp_BranchesAddNewBranch");
                    JIMessageBox.ShowSuccessMessage("Record Is Added Successfully");
                    // MessageBox.Show("Record Is Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                this.Close();

            }


        }

        private void SaveOrUpdateRecord(string StoredProcName)
        {
            DBSqlServer db = new DBSqlServer(AppSetting.connectionString());
            db.SaveOrUpdateRecord(StoredProcName, GetObject());
        }

        private Branch GetObject()
        {
            Branch branch = new Branch();
            branch.BranchId = (this.IsUpdate) ? this.BranchId : 0;
            branch.BranchName = BranchNameTextBox.Text;
            branch.Email = EmailAddressTextBox.Text;
            branch.Telephone = PhoneNumberTextBox.Text;
            branch.Website = WebsiteAddressTextBox.Text;
            branch.AddressLine = AddressLineTextBox.Text;
            branch.CityId =Convert.ToInt32( CityNameComboBox.SelectedValue);
            branch.DistinctId = Convert.ToInt32(DistinctNameComboBox.SelectedValue);
            branch.PostalCode = PostalCodeTextBox.Text;
            branch.BranchImage = (LogoPictureBox.Image==null)? null: ImageManipulation.GetPhoto(LogoPictureBox);
            branch.CreatedBy = LoggedInUser.UserName;




            return branch;
        }

       

        private bool IsFormValidated()
        {
            if(BranchNameTextBox.Text.Trim() ==string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Branch Name is Required");
                //MessageBox.Show("Branch Name is Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                BranchNameTextBox.Focus();
                return false;
            }


            if (EmailAddressTextBox.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Email is Required");
               // MessageBox.Show("Email is Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                EmailAddressTextBox.Focus();
                return false;
            }


            if (PhoneNumberTextBox.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Phone is Required");
                //MessageBox.Show("Phone is Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                PhoneNumberTextBox.Focus();
                return false;
            }

            return true;
        }

        private void TopPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void GetPhotoPictureBox_Click(object sender, EventArgs e)
        {
            GetPhoto();
        }

        private void ClearPictureBox_Click(object sender, EventArgs e)
        {
            LogoPictureBox.Image = null;
        }
    }
}
