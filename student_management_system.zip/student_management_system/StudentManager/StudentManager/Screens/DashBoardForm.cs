﻿using StudentManager.Screens.Branches;
using StudentManager.Screens.Employees;
using StudentManager.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManager.Screens
{
    public partial class DashBoardForm : TemplateForm
    {
        public DashBoardForm()
        {
            InitializeComponent();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutStudentManagerToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void DashBoardForm_Load(object sender, EventArgs e)
        {

        }

        private void ManageBranchesToolStripButton2_Click(object sender, EventArgs e)
        {
            ManageBranchesForm mbf = new ManageBranchesForm();
            mbf.ShowDialog();
        }

        private void ManageEmployeesToolStripButton4_Click(object sender, EventArgs e)
        {
            ManageEmployeesForm mef = new ManageEmployeesForm();
            mef.ShowDialog();
        }
    }
}
