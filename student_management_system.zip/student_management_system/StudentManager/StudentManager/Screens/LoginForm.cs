﻿using JIDBFramework;
using JIDBFramework.Windows;
using StudentManager.Models.Users;
using StudentManager.Screens.Templates;
using StudentManager.Utitlities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManager.Screens
{
    public partial class LoginForm : TemplateForm
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if(IsFormValid())
            {
                DBSqlServer db = new DBSqlServer(AppSetting.connectionString());
                bool isLoginDetailsCorrect = Convert.ToBoolean( db.GetScalarValue("usp_UsersCheckLoginDetails",GetParameneters()));

                if(isLoginDetailsCorrect)
                {
                    GetLoggedInUserSettings();
            this.Hide();
            DashBoardForm df = new DashBoardForm();
            df.Show();
                }

                else
                {
                    JIMessageBox.ShowErrorMessage("User Name / Password is incorrect ");
                   // MessageBox.Show("User Name / Password is incorrect ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            


        }

        private void GetLoggedInUserSettings()
        {

            LoggedInUser.UserName = UserNameTextBox.Text.Trim();
        }

        private DbParameter[] GetParameneters()
        {
            List<DbParameter> parameters = new List<DbParameter>();

            DbParameter dbparam1 = new DbParameter();
            dbparam1.Parameter = "@UserName";
            dbparam1.Value = UserNameTextBox.Text;
            parameters.Add(dbparam1);


            DbParameter dbparam2 = new DbParameter();
            dbparam2.Parameter = "@Password";
            dbparam2.Value = PasswordTextBox.Text;
            parameters.Add(dbparam2);





            return parameters.ToArray();
        }

        private bool IsFormValid()
        {
            if(UserNameTextBox.Text.Trim()== string.Empty)
            {
                JIMessageBox.ShowErrorMessage("User Name is required !");
                // MessageBox.Show("User Name is required !","Error" , MessageBoxButtons.OK , MessageBoxIcon.Error);
                UserNameTextBox.Clear();
                UserNameTextBox.Focus();
                return false;
            }


            if (PasswordTextBox.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Password is required !");
                // MessageBox.Show("Password is required !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                PasswordTextBox.Clear();
                PasswordTextBox.Focus();
                return false;
            }


            return true;
        }
    }
}
