﻿namespace StudentManager.Screens
{
    partial class DashBoardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashBoardForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutStudentManagerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.NewStudentToolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ManageBranchesToolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.EditProfileToolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ManageEmployeesToolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.ManageReportsToolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.SystemSetupToolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.DashBoardDataGridView = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DashBoardDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolStripMenuItem1,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1170, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem2});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "&File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem2
            // 
            this.exitToolStripMenuItem2.Name = "exitToolStripMenuItem2";
            this.exitToolStripMenuItem2.Size = new System.Drawing.Size(108, 26);
            this.exitToolStripMenuItem2.Text = "&Exit";
            this.exitToolStripMenuItem2.Click += new System.EventHandler(this.exitToolStripMenuItem2_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(25, 24);
            this.toolStripMenuItem1.Text = "|";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(108, 26);
            this.exitToolStripMenuItem.Text = "&Exit";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutStudentManagerToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutStudentManagerToolStripMenuItem
            // 
            this.aboutStudentManagerToolStripMenuItem.Name = "aboutStudentManagerToolStripMenuItem";
            this.aboutStudentManagerToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.aboutStudentManagerToolStripMenuItem.Text = "About Student Manager";
            this.aboutStudentManagerToolStripMenuItem.Click += new System.EventHandler(this.aboutStudentManagerToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NewStudentToolStripButton1,
            this.toolStripSeparator1,
            this.ManageBranchesToolStripButton2,
            this.toolStripSeparator2,
            this.EditProfileToolStripButton3,
            this.toolStripSeparator3,
            this.ManageEmployeesToolStripButton4,
            this.toolStripSeparator4,
            this.ManageReportsToolStripButton5,
            this.toolStripSeparator5,
            this.SystemSetupToolStripButton6,
            this.toolStripSeparator6,
            this.toolStripButton7});
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1170, 91);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // NewStudentToolStripButton1
            // 
            this.NewStudentToolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("NewStudentToolStripButton1.Image")));
            this.NewStudentToolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.NewStudentToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.NewStudentToolStripButton1.Name = "NewStudentToolStripButton1";
            this.NewStudentToolStripButton1.Size = new System.Drawing.Size(98, 88);
            this.NewStudentToolStripButton1.Text = "New Student";
            this.NewStudentToolStripButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.NewStudentToolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 91);
            // 
            // ManageBranchesToolStripButton2
            // 
            this.ManageBranchesToolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("ManageBranchesToolStripButton2.Image")));
            this.ManageBranchesToolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ManageBranchesToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ManageBranchesToolStripButton2.Name = "ManageBranchesToolStripButton2";
            this.ManageBranchesToolStripButton2.Size = new System.Drawing.Size(130, 88);
            this.ManageBranchesToolStripButton2.Text = "Manage Branches";
            this.ManageBranchesToolStripButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ManageBranchesToolStripButton2.Click += new System.EventHandler(this.ManageBranchesToolStripButton2_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 91);
            // 
            // EditProfileToolStripButton3
            // 
            this.EditProfileToolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("EditProfileToolStripButton3.Image")));
            this.EditProfileToolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.EditProfileToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.EditProfileToolStripButton3.Name = "EditProfileToolStripButton3";
            this.EditProfileToolStripButton3.Size = new System.Drawing.Size(86, 88);
            this.EditProfileToolStripButton3.Text = "Edit Profile";
            this.EditProfileToolStripButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 91);
            // 
            // ManageEmployeesToolStripButton4
            // 
            this.ManageEmployeesToolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("ManageEmployeesToolStripButton4.Image")));
            this.ManageEmployeesToolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ManageEmployeesToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ManageEmployeesToolStripButton4.Name = "ManageEmployeesToolStripButton4";
            this.ManageEmployeesToolStripButton4.Size = new System.Drawing.Size(143, 88);
            this.ManageEmployeesToolStripButton4.Text = "Manage Employees";
            this.ManageEmployeesToolStripButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ManageEmployeesToolStripButton4.Click += new System.EventHandler(this.ManageEmployeesToolStripButton4_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 91);
            // 
            // ManageReportsToolStripButton5
            // 
            this.ManageReportsToolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("ManageReportsToolStripButton5.Image")));
            this.ManageReportsToolStripButton5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ManageReportsToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ManageReportsToolStripButton5.Name = "ManageReportsToolStripButton5";
            this.ManageReportsToolStripButton5.Size = new System.Drawing.Size(122, 88);
            this.ManageReportsToolStripButton5.Text = "Manage Reports";
            this.ManageReportsToolStripButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 91);
            // 
            // SystemSetupToolStripButton6
            // 
            this.SystemSetupToolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("SystemSetupToolStripButton6.Image")));
            this.SystemSetupToolStripButton6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.SystemSetupToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SystemSetupToolStripButton6.Name = "SystemSetupToolStripButton6";
            this.SystemSetupToolStripButton6.Size = new System.Drawing.Size(102, 88);
            this.SystemSetupToolStripButton6.Text = "System Setup";
            this.SystemSetupToolStripButton6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 91);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(133, 88);
            this.toolStripButton7.Text = "Help And Support";
            this.toolStripButton7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // DashBoardDataGridView
            // 
            this.DashBoardDataGridView.AllowUserToAddRows = false;
            this.DashBoardDataGridView.AllowUserToDeleteRows = false;
            this.DashBoardDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DashBoardDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DashBoardDataGridView.Location = new System.Drawing.Point(0, 136);
            this.DashBoardDataGridView.Name = "DashBoardDataGridView";
            this.DashBoardDataGridView.ReadOnly = true;
            this.DashBoardDataGridView.RowTemplate.Height = 24;
            this.DashBoardDataGridView.Size = new System.Drawing.Size(1093, 321);
            this.DashBoardDataGridView.TabIndex = 2;
            // 
            // DashBoardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1170, 456);
            this.Controls.Add(this.DashBoardDataGridView);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = true;
            this.MinimizeBox = true;
            this.Name = "DashBoardForm";
            this.ShowInTaskbar = true;
            this.Text = "DashBoardForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.DashBoardForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DashBoardDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem aboutStudentManagerToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton NewStudentToolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton ManageBranchesToolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton EditProfileToolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton ManageEmployeesToolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton ManageReportsToolStripButton5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton SystemSetupToolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.DataGridView DashBoardDataGridView;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
    }
}