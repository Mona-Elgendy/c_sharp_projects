﻿namespace StudentManager.Screens.Employees
{
    partial class EmployeeInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeInfoForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.qualificationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.previousToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.sendToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.byEmailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LabelTopPanel = new System.Windows.Forms.Panel();
            this.TopPanelLabel = new System.Windows.Forms.Label();
            this.PhotoPictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.EmployeeIdTextBox = new System.Windows.Forms.TextBox();
            this.FullNameTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.NICNumberTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.EmailTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.MobileNumberTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.PhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.GenderComboBox = new System.Windows.Forms.ComboBox();
            this.BranchComboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ClearPictureBox = new System.Windows.Forms.PictureBox();
            this.GetPhotoPictureBox = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.StartingtSalarytextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.JobTitleComboBox = new System.Windows.Forms.ComboBox();
            this.CurrentSalarytextBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.PostalCodetextBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.DistrictComboBox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.CityComboBox = new System.Windows.Forms.ComboBox();
            this.AddressLinetextBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.QualificationsDataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.PreviousEmploymentDataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.CommentsTextBox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.ReasonLeftComboBox = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.HasLeftComboBox = new System.Windows.Forms.ComboBox();
            this.EmploymentDateDateTimePicker = new JIDBFramework.Windows.WinControls.JIDateTimePicker();
            this.DateOfBirthTimePicker = new JIDBFramework.Windows.WinControls.JIDateTimePicker();
            this.DateLeftDateTimePicker = new JIDBFramework.Windows.WinControls.JIDateTimePicker();
            this.menuStrip1.SuspendLayout();
            this.LabelTopPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PhotoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClearPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GetPhotoPictureBox)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.QualificationsDataGridView1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PreviousEmploymentDataGridView1)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem,
            this.toolStripMenuItem1,
            this.addNewEmployeeToolStripMenuItem,
            this.toolStripMenuItem2,
            this.addToolStripMenuItem,
            this.toolStripMenuItem3,
            this.sendToolStripMenuItem,
            this.toolStripMenuItem4,
            this.printToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1125, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(57, 24);
            this.closeToolStripMenuItem.Text = "&Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(25, 24);
            this.toolStripMenuItem1.Text = "|";
            // 
            // addNewEmployeeToolStripMenuItem
            // 
            this.addNewEmployeeToolStripMenuItem.Name = "addNewEmployeeToolStripMenuItem";
            this.addNewEmployeeToolStripMenuItem.Size = new System.Drawing.Size(103, 24);
            this.addNewEmployeeToolStripMenuItem.Text = "Save Record";
            this.addNewEmployeeToolStripMenuItem.Click += new System.EventHandler(this.addNewEmployeeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Enabled = false;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(25, 24);
            this.toolStripMenuItem2.Text = "|";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.qualificationToolStripMenuItem,
            this.previousToolStripMenuItem,
            this.userAccountToolStripMenuItem});
            this.addToolStripMenuItem.Enabled = false;
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(49, 24);
            this.addToolStripMenuItem.Text = "Add";
            // 
            // qualificationToolStripMenuItem
            // 
            this.qualificationToolStripMenuItem.Name = "qualificationToolStripMenuItem";
            this.qualificationToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.qualificationToolStripMenuItem.Text = "Qualification";
            // 
            // previousToolStripMenuItem
            // 
            this.previousToolStripMenuItem.Name = "previousToolStripMenuItem";
            this.previousToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.previousToolStripMenuItem.Text = "Previous Employment";
            // 
            // userAccountToolStripMenuItem
            // 
            this.userAccountToolStripMenuItem.Name = "userAccountToolStripMenuItem";
            this.userAccountToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.userAccountToolStripMenuItem.Text = "User Account";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Enabled = false;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(25, 24);
            this.toolStripMenuItem3.Text = "|";
            // 
            // sendToolStripMenuItem
            // 
            this.sendToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.byEmailToolStripMenuItem});
            this.sendToolStripMenuItem.Enabled = false;
            this.sendToolStripMenuItem.Name = "sendToolStripMenuItem";
            this.sendToolStripMenuItem.Size = new System.Drawing.Size(54, 24);
            this.sendToolStripMenuItem.Text = "Send";
            // 
            // byEmailToolStripMenuItem
            // 
            this.byEmailToolStripMenuItem.Name = "byEmailToolStripMenuItem";
            this.byEmailToolStripMenuItem.Size = new System.Drawing.Size(141, 26);
            this.byEmailToolStripMenuItem.Text = "By Email";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Enabled = false;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(25, 24);
            this.toolStripMenuItem4.Text = "|";
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Enabled = false;
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.printToolStripMenuItem.Text = "Print";
            // 
            // LabelTopPanel
            // 
            this.LabelTopPanel.BackColor = System.Drawing.Color.DarkSlateGray;
            this.LabelTopPanel.Controls.Add(this.TopPanelLabel);
            this.LabelTopPanel.ForeColor = System.Drawing.Color.White;
            this.LabelTopPanel.Location = new System.Drawing.Point(0, 57);
            this.LabelTopPanel.Name = "LabelTopPanel";
            this.LabelTopPanel.Size = new System.Drawing.Size(1022, 87);
            this.LabelTopPanel.TabIndex = 1;
            // 
            // TopPanelLabel
            // 
            this.TopPanelLabel.AutoSize = true;
            this.TopPanelLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TopPanelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TopPanelLabel.Location = new System.Drawing.Point(33, 21);
            this.TopPanelLabel.Name = "TopPanelLabel";
            this.TopPanelLabel.Size = new System.Drawing.Size(233, 38);
            this.TopPanelLabel.TabIndex = 0;
            this.TopPanelLabel.Text = "Employee Name";
            // 
            // PhotoPictureBox
            // 
            this.PhotoPictureBox.BackColor = System.Drawing.Color.White;
            this.PhotoPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PhotoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("PhotoPictureBox.Image")));
            this.PhotoPictureBox.Location = new System.Drawing.Point(23, 161);
            this.PhotoPictureBox.Name = "PhotoPictureBox";
            this.PhotoPictureBox.Size = new System.Drawing.Size(184, 211);
            this.PhotoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PhotoPictureBox.TabIndex = 2;
            this.PhotoPictureBox.TabStop = false;
            this.PhotoPictureBox.DoubleClick += new System.EventHandler(this.PhotoPictureBox_DoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(222, 179);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Employee ID";
            // 
            // EmployeeIdTextBox
            // 
            this.EmployeeIdTextBox.Enabled = false;
            this.EmployeeIdTextBox.Location = new System.Drawing.Point(369, 176);
            this.EmployeeIdTextBox.Name = "EmployeeIdTextBox";
            this.EmployeeIdTextBox.Size = new System.Drawing.Size(246, 26);
            this.EmployeeIdTextBox.TabIndex = 4;
            // 
            // FullNameTextBox
            // 
            this.FullNameTextBox.Location = new System.Drawing.Point(745, 176);
            this.FullNameTextBox.Name = "FullNameTextBox";
            this.FullNameTextBox.Size = new System.Drawing.Size(252, 26);
            this.FullNameTextBox.TabIndex = 6;
            this.FullNameTextBox.TextChanged += new System.EventHandler(this.FullNameTextBox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(654, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Full Name";
            // 
            // NICNumberTextBox
            // 
            this.NICNumberTextBox.Location = new System.Drawing.Point(751, 238);
            this.NICNumberTextBox.Name = "NICNumberTextBox";
            this.NICNumberTextBox.Size = new System.Drawing.Size(246, 26);
            this.NICNumberTextBox.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(659, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "NIC";
            // 
            // EmailTextBox
            // 
            this.EmailTextBox.Location = new System.Drawing.Point(369, 291);
            this.EmailTextBox.Name = "EmailTextBox";
            this.EmailTextBox.Size = new System.Drawing.Size(246, 26);
            this.EmailTextBox.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(222, 291);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Email Address";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(222, 235);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 20);
            this.label7.TabIndex = 15;
            this.label7.Text = "Date Of Birth";
            // 
            // MobileNumberTextBox
            // 
            this.MobileNumberTextBox.Location = new System.Drawing.Point(751, 291);
            this.MobileNumberTextBox.Name = "MobileNumberTextBox";
            this.MobileNumberTextBox.Size = new System.Drawing.Size(246, 26);
            this.MobileNumberTextBox.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(659, 294);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 20);
            this.label8.TabIndex = 18;
            this.label8.Text = "Mobile";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(659, 344);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 20);
            this.label9.TabIndex = 22;
            this.label9.Text = "Gender";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // PhoneNumberTextBox
            // 
            this.PhoneNumberTextBox.Location = new System.Drawing.Point(372, 344);
            this.PhoneNumberTextBox.Name = "PhoneNumberTextBox";
            this.PhoneNumberTextBox.Size = new System.Drawing.Size(243, 26);
            this.PhoneNumberTextBox.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(222, 344);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 20);
            this.label10.TabIndex = 20;
            this.label10.Text = "Phone";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(222, 402);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 20);
            this.label5.TabIndex = 24;
            this.label5.Text = "Employment Date";
            // 
            // GenderComboBox
            // 
            this.GenderComboBox.FormattingEnabled = true;
            this.GenderComboBox.Location = new System.Drawing.Point(751, 344);
            this.GenderComboBox.Name = "GenderComboBox";
            this.GenderComboBox.Size = new System.Drawing.Size(246, 28);
            this.GenderComboBox.TabIndex = 26;
            // 
            // BranchComboBox
            // 
            this.BranchComboBox.FormattingEnabled = true;
            this.BranchComboBox.Location = new System.Drawing.Point(751, 402);
            this.BranchComboBox.Name = "BranchComboBox";
            this.BranchComboBox.Size = new System.Drawing.Size(246, 28);
            this.BranchComboBox.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(660, 402);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 20);
            this.label6.TabIndex = 27;
            this.label6.Text = "Branch";
            // 
            // ClearPictureBox
            // 
            this.ClearPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("ClearPictureBox.Image")));
            this.ClearPictureBox.Location = new System.Drawing.Point(118, 389);
            this.ClearPictureBox.Name = "ClearPictureBox";
            this.ClearPictureBox.Size = new System.Drawing.Size(55, 50);
            this.ClearPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ClearPictureBox.TabIndex = 29;
            this.ClearPictureBox.TabStop = false;
            this.ClearPictureBox.Click += new System.EventHandler(this.ClearPictureBox_Click);
            // 
            // GetPhotoPictureBox
            // 
            this.GetPhotoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("GetPhotoPictureBox.Image")));
            this.GetPhotoPictureBox.Location = new System.Drawing.Point(44, 389);
            this.GetPhotoPictureBox.Name = "GetPhotoPictureBox";
            this.GetPhotoPictureBox.Size = new System.Drawing.Size(56, 50);
            this.GetPhotoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GetPhotoPictureBox.TabIndex = 30;
            this.GetPhotoPictureBox.TabStop = false;
            this.GetPhotoPictureBox.Click += new System.EventHandler(this.GetPhotoPictureBox_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(23, 475);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(997, 262);
            this.tabControl1.TabIndex = 31;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(989, 229);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Employee Details";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.StartingtSalarytextBox);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.JobTitleComboBox);
            this.groupBox2.Controls.Add(this.CurrentSalarytextBox);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.groupBox2.Location = new System.Drawing.Point(495, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(459, 190);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Employment Details";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // StartingtSalarytextBox
            // 
            this.StartingtSalarytextBox.Location = new System.Drawing.Point(161, 118);
            this.StartingtSalarytextBox.Name = "StartingtSalarytextBox";
            this.StartingtSalarytextBox.Size = new System.Drawing.Size(286, 26);
            this.StartingtSalarytextBox.TabIndex = 37;
            this.StartingtSalarytextBox.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 118);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(145, 20);
            this.label15.TabIndex = 36;
            this.label15.Text = "Starting Salary ($)";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // JobTitleComboBox
            // 
            this.JobTitleComboBox.FormattingEnabled = true;
            this.JobTitleComboBox.Location = new System.Drawing.Point(161, 47);
            this.JobTitleComboBox.Name = "JobTitleComboBox";
            this.JobTitleComboBox.Size = new System.Drawing.Size(286, 28);
            this.JobTitleComboBox.TabIndex = 33;
            this.JobTitleComboBox.SelectedIndexChanged += new System.EventHandler(this.comboBox6_SelectedIndexChanged);
            // 
            // CurrentSalarytextBox
            // 
            this.CurrentSalarytextBox.Location = new System.Drawing.Point(161, 81);
            this.CurrentSalarytextBox.Name = "CurrentSalarytextBox";
            this.CurrentSalarytextBox.Size = new System.Drawing.Size(286, 26);
            this.CurrentSalarytextBox.TabIndex = 33;
            this.CurrentSalarytextBox.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 47);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 20);
            this.label17.TabIndex = 32;
            this.label17.Text = "Job Title";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 84);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(143, 20);
            this.label18.TabIndex = 32;
            this.label18.Text = "Current Salary ($)";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.PostalCodetextBox);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.DistrictComboBox);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.CityComboBox);
            this.groupBox1.Controls.Add(this.AddressLinetextBox);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.groupBox1.Location = new System.Drawing.Point(19, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(459, 190);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Address";
            // 
            // PostalCodetextBox
            // 
            this.PostalCodetextBox.Location = new System.Drawing.Point(139, 148);
            this.PostalCodetextBox.Name = "PostalCodetextBox";
            this.PostalCodetextBox.Size = new System.Drawing.Size(308, 26);
            this.PostalCodetextBox.TabIndex = 37;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(23, 151);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 20);
            this.label14.TabIndex = 36;
            this.label14.Text = "Postal Code";
            // 
            // DistrictComboBox
            // 
            this.DistrictComboBox.FormattingEnabled = true;
            this.DistrictComboBox.Location = new System.Drawing.Point(139, 111);
            this.DistrictComboBox.Name = "DistrictComboBox";
            this.DistrictComboBox.Size = new System.Drawing.Size(308, 28);
            this.DistrictComboBox.TabIndex = 35;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(23, 111);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 20);
            this.label13.TabIndex = 34;
            this.label13.Text = "District";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // CityComboBox
            // 
            this.CityComboBox.FormattingEnabled = true;
            this.CityComboBox.Location = new System.Drawing.Point(139, 77);
            this.CityComboBox.Name = "CityComboBox";
            this.CityComboBox.Size = new System.Drawing.Size(308, 28);
            this.CityComboBox.TabIndex = 33;
            // 
            // AddressLinetextBox
            // 
            this.AddressLinetextBox.Location = new System.Drawing.Point(139, 42);
            this.AddressLinetextBox.Name = "AddressLinetextBox";
            this.AddressLinetextBox.Size = new System.Drawing.Size(308, 26);
            this.AddressLinetextBox.TabIndex = 33;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(23, 77);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 20);
            this.label12.TabIndex = 32;
            this.label12.Text = "City";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 45);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 20);
            this.label11.TabIndex = 32;
            this.label11.Text = "Address Line";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.QualificationsDataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(989, 229);
            this.tabPage1.TabIndex = 4;
            this.tabPage1.Text = "Qualifications";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // QualificationsDataGridView1
            // 
            this.QualificationsDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.QualificationsDataGridView1.Location = new System.Drawing.Point(3, 6);
            this.QualificationsDataGridView1.Name = "QualificationsDataGridView1";
            this.QualificationsDataGridView1.RowTemplate.Height = 24;
            this.QualificationsDataGridView1.Size = new System.Drawing.Size(980, 217);
            this.QualificationsDataGridView1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.PreviousEmploymentDataGridView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(989, 229);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Previous Employments";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // PreviousEmploymentDataGridView1
            // 
            this.PreviousEmploymentDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PreviousEmploymentDataGridView1.Location = new System.Drawing.Point(6, 3);
            this.PreviousEmploymentDataGridView1.Name = "PreviousEmploymentDataGridView1";
            this.PreviousEmploymentDataGridView1.RowTemplate.Height = 24;
            this.PreviousEmploymentDataGridView1.Size = new System.Drawing.Size(980, 223);
            this.PreviousEmploymentDataGridView1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.DateLeftDateTimePicker);
            this.tabPage4.Controls.Add(this.CommentsTextBox);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.label20);
            this.tabPage4.Controls.Add(this.ReasonLeftComboBox);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.HasLeftComboBox);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(989, 229);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Leaving Comments";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // CommentsTextBox
            // 
            this.CommentsTextBox.Location = new System.Drawing.Point(45, 142);
            this.CommentsTextBox.Multiline = true;
            this.CommentsTextBox.Name = "CommentsTextBox";
            this.CommentsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.CommentsTextBox.Size = new System.Drawing.Size(925, 69);
            this.CommentsTextBox.TabIndex = 7;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(45, 119);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(140, 20);
            this.label21.TabIndex = 6;
            this.label21.Text = "Comment (If Any)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(45, 83);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(100, 20);
            this.label20.TabIndex = 5;
            this.label20.Text = "Reason Left";
            // 
            // ReasonLeftComboBox
            // 
            this.ReasonLeftComboBox.FormattingEnabled = true;
            this.ReasonLeftComboBox.Location = new System.Drawing.Point(199, 80);
            this.ReasonLeftComboBox.Name = "ReasonLeftComboBox";
            this.ReasonLeftComboBox.Size = new System.Drawing.Size(518, 28);
            this.ReasonLeftComboBox.TabIndex = 4;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(45, 46);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 20);
            this.label19.TabIndex = 2;
            this.label19.Text = "Date Left";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(45, 9);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 20);
            this.label16.TabIndex = 1;
            this.label16.Text = "Has Left";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // HasLeftComboBox
            // 
            this.HasLeftComboBox.FormattingEnabled = true;
            this.HasLeftComboBox.Location = new System.Drawing.Point(199, 9);
            this.HasLeftComboBox.Name = "HasLeftComboBox";
            this.HasLeftComboBox.Size = new System.Drawing.Size(200, 28);
            this.HasLeftComboBox.TabIndex = 0;
            this.HasLeftComboBox.SelectedIndexChanged += new System.EventHandler(this.HasLeftComboBox_SelectedIndexChanged);
            // 
            // EmploymentDateDateTimePicker
            // 
            this.EmploymentDateDateTimePicker.CustomFormat = " ";
            this.EmploymentDateDateTimePicker.DateFormat = JIDBFramework.Windows.WinControls.JIDateTimePicker.DataFormat.British;
            this.EmploymentDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.EmploymentDateDateTimePicker.Location = new System.Drawing.Point(372, 399);
            this.EmploymentDateDateTimePicker.MakeEmpty = true;
            this.EmploymentDateDateTimePicker.Name = "EmploymentDateDateTimePicker";
            this.EmploymentDateDateTimePicker.Size = new System.Drawing.Size(243, 26);
            this.EmploymentDateDateTimePicker.TabIndex = 33;
            // 
            // DateOfBirthTimePicker
            // 
            this.DateOfBirthTimePicker.CustomFormat = "yyyy.MM.dd";
            this.DateOfBirthTimePicker.DateFormat = JIDBFramework.Windows.WinControls.JIDateTimePicker.DataFormat.ANSI;
            this.DateOfBirthTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DateOfBirthTimePicker.Location = new System.Drawing.Point(369, 237);
            this.DateOfBirthTimePicker.MakeEmpty = false;
            this.DateOfBirthTimePicker.Name = "DateOfBirthTimePicker";
            this.DateOfBirthTimePicker.Size = new System.Drawing.Size(246, 26);
            this.DateOfBirthTimePicker.TabIndex = 32;
            // 
            // DateLeftDateTimePicker
            // 
            this.DateLeftDateTimePicker.CustomFormat = " ";
            this.DateLeftDateTimePicker.DateFormat = JIDBFramework.Windows.WinControls.JIDateTimePicker.DataFormat.British;
            this.DateLeftDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DateLeftDateTimePicker.Location = new System.Drawing.Point(199, 44);
            this.DateLeftDateTimePicker.MakeEmpty = true;
            this.DateLeftDateTimePicker.Name = "DateLeftDateTimePicker";
            this.DateLeftDateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.DateLeftDateTimePicker.TabIndex = 8;
            // 
            // EmployeeInfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 744);
            this.Controls.Add(this.EmploymentDateDateTimePicker);
            this.Controls.Add(this.DateOfBirthTimePicker);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.GetPhotoPictureBox);
            this.Controls.Add(this.ClearPictureBox);
            this.Controls.Add(this.BranchComboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.GenderComboBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.PhoneNumberTextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.MobileNumberTextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.EmailTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.NICNumberTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.FullNameTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.EmployeeIdTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PhotoPictureBox);
            this.Controls.Add(this.LabelTopPanel);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "EmployeeInfoForm";
            this.Text = "Employee Info Screen";
            this.Load += new System.EventHandler(this.EmployeeInfoForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.LabelTopPanel.ResumeLayout(false);
            this.LabelTopPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PhotoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClearPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GetPhotoPictureBox)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.QualificationsDataGridView1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PreviousEmploymentDataGridView1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem addNewEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem sendToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.Panel LabelTopPanel;
        private System.Windows.Forms.Label TopPanelLabel;
        private System.Windows.Forms.ToolStripMenuItem qualificationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem previousToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem byEmailToolStripMenuItem;
        private System.Windows.Forms.PictureBox PhotoPictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox EmployeeIdTextBox;
        private System.Windows.Forms.TextBox FullNameTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox NICNumberTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox EmailTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox MobileNumberTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox PhoneNumberTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox GenderComboBox;
        private System.Windows.Forms.ComboBox BranchComboBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox ClearPictureBox;
        private System.Windows.Forms.PictureBox GetPhotoPictureBox;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox DistrictComboBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox CityComboBox;
        private System.Windows.Forms.TextBox AddressLinetextBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox StartingtSalarytextBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox JobTitleComboBox;
        private System.Windows.Forms.TextBox CurrentSalarytextBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox PostalCodetextBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView QualificationsDataGridView1;
        private System.Windows.Forms.DataGridView PreviousEmploymentDataGridView1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox HasLeftComboBox;
        private System.Windows.Forms.TextBox CommentsTextBox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox ReasonLeftComboBox;
        private System.Windows.Forms.Label label19;
        private JIDBFramework.Windows.WinControls.JIDateTimePicker DateOfBirthTimePicker;
        private JIDBFramework.Windows.WinControls.JIDateTimePicker EmploymentDateDateTimePicker;
        private JIDBFramework.Windows.WinControls.JIDateTimePicker DateLeftDateTimePicker;
    }
}