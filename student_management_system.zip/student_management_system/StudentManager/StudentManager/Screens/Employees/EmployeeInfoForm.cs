﻿using JIDBFramework;
using JIDBFramework.Windows;
using StudentManager.Models.Employees;
using StudentManager.Models.Users;
using StudentManager.Screens.Templates;
using StudentManager.Utitlities;
using StudentManager.Utitlities.Lists;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManager.Screens.Employees
{
    public partial class EmployeeInfoForm : TemplateForm
    {
        public EmployeeInfoForm()
        {
            InitializeComponent();
        }
        public int EmployeeId { get; set; }
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void EmployeeInfoForm_Load(object sender, EventArgs e)
        {
            LoadDataIntoComboBoxes();

            if (this.IsUpdate)
            {
                LoadDataAndBindIntoControls();
                EnableButtons();
            }
            else
            {
                GenerateEmployeeId();
                SetLeavengCommentSection();
            }
        }

        private void SetLeavengCommentSection()
        {
            HasLeftComboBox.Text = "No";
            EnabledDisabledControls(false);
        }

        private void LoadDataAndBindIntoControls()
        {
            DBSqlServer db = new DBSqlServer(AppSetting.connectionString());
            DataTable dtEmployee = db.GetDataList("usp_EmployeesGetEmployeeDetailsById", new DbParameter { Parameter = "@EmployeeId", Value =this.EmployeeId });
            DataRow row = dtEmployee.Rows[0];

            EmployeeIdTextBox.Text = row["EmployeeId"].ToString();
            FullNameTextBox.Text = row["Fullname"].ToString();
            EmailTextBox.Text = row["EmailAddress"].ToString();
            NICNumberTextBox.Text = row["NICNumber"].ToString();
            MobileNumberTextBox.Text = row["Mobile"].ToString();
            PhoneNumberTextBox.Text = row["Telephone"].ToString();
            DateOfBirthTimePicker.Value = Convert.ToDateTime(row["DateOfBirth"]);

            GenderComboBox.SelectedValue =row["genderId"];
            BranchComboBox.SelectedValue = row["BranchId"];
            EmploymentDateDateTimePicker.Value = Convert.ToDateTime(row["EmploymentDate"]);

            PhotoPictureBox.Image = (row["Photo"] is DBNull) ? null : ImageManipulation.PutPhoto((byte[])row["Photo"]);


            AddressLinetextBox.Text = row["AddressLine"].ToString();
            PostalCodetextBox.Text = row["PostalCode"].ToString();
            StartingtSalarytextBox.Text = row["StartingSalary"].ToString();
            CurrentSalarytextBox.Text = row["CurrentSalary"].ToString();
            CityComboBox.SelectedValue = row["CityId"];
            JobTitleComboBox.SelectedValue = row["JobTitled"];
            DistrictComboBox.SelectedValue = row["DistrictId"];

            HasLeftComboBox.Text = (Convert.ToBoolean(row["HasLeft"]) == true) ? "Yes" : "No";
            if(row["DateLeft"] is DBNull)
            {
                DateLeftDateTimePicker.CustomFormat = " ";
            }
            else
            {
                DateLeftDateTimePicker.Value = Convert.ToDateTime(row["DateLeft"]);
            }
           
            ReasonLeftComboBox.SelectedValue = row["ReasonLeftId"];
            CommentsTextBox.Text = row["Comments"].ToString();

            
        }

        private void LoadDataIntoComboBoxes()
        {
         Listdata.LoadDataIntoComboBox(BranchComboBox, "usp_GetAllBranchNames");

         

            Listdata.LoadDataIntoComboBox(GenderComboBox, new DbParameter
            {
                Parameter = "@ListTypeId",
                Value = ListTypes.Gender
            });

            Listdata.LoadDataIntoComboBox(CityComboBox, new DbParameter
            {
                Parameter = "@ListTypeId",
                Value = ListTypes.City
            });

            Listdata.LoadDataIntoComboBox(DistrictComboBox, new DbParameter
            {
                Parameter = "@ListTypeId",
                Value = ListTypes.District
            });

            Listdata.LoadDataIntoComboBox(JobTitleComboBox, new DbParameter
            {
                Parameter = "@ListTypeId",
                Value = ListTypes.EmployeeJobTitle
            });
            Listdata.LoadDataIntoComboBox(HasLeftComboBox, new DbParameter
            {
                Parameter = "@ListTypeId",
                Value = ListTypes.YesNo
            });
            Listdata.LoadDataIntoComboBox(ReasonLeftComboBox, new DbParameter
            {
                Parameter = "@ListTypeId",
                Value = ListTypes.EmployeeReasonLeft
            });


        }

        private void GenerateEmployeeId()
        {
            DBSqlServer db = new DBSqlServer(AppSetting.connectionString());
            EmployeeIdTextBox.Text = db.GetScalarValue("usp_EmployeesGeneratenewEmployeeID").ToString();
        }

        private void PhotoPictureBox_DoubleClick(object sender, EventArgs e)
        {
            GetPhoto();
        }

        private void GetPhoto()
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Title = "Please Select the Photo";
            ofd.Filter = "Photo File (*.png;*.jpg;*.bmp;*.gif) |*.png;*.jpg;*.bmp;*.gif";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                PhotoPictureBox.Image = new Bitmap(ofd.FileName);
            }
        }

        private void GetPhotoPictureBox_Click(object sender, EventArgs e)
        {
            GetPhoto();
        }

        private void ClearPictureBox_Click(object sender, EventArgs e)
        {
            PhotoPictureBox.Image = null;
        }

        private void addNewEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(IsFormValid())
            {
                if(this.IsUpdate)
                {
                    SaveOrUpdateRecord("usp_EmployeesUpdateEmployeeDetails");
                    JIMessageBox.ShowSuccessMessage("Record Updated Successfully");
                }
                else
                {
                    SaveOrUpdateRecord("usp_EmployeesAddNewEmployee");
                    JIMessageBox.ShowSuccessMessage("Record Added Successfully");

                    this.IsUpdate = true;
                    EnableButtons();
                }
            }
        }

        private void EnableButtons()
        {
            addToolStripMenuItem.Enabled = true;
            sendToolStripMenuItem.Enabled = true;
            printToolStripMenuItem.Enabled = true;

        }

        private void SaveOrUpdateRecord(string StoredProcName)
        {
            DBSqlServer db = new DBSqlServer(AppSetting.connectionString());
            db.SaveOrUpdateRecord(StoredProcName , GetObject());
        }

        private Employee GetObject()
        {
            Employee employee = new Employee();
            employee.EmployeeId = Convert.ToInt32(EmployeeIdTextBox.Text);
            employee.Fullname = FullNameTextBox.Text.Trim();
            employee.DateOfBirth = DateOfBirthTimePicker.Value.Date;
            employee.NICNumber = NICNumberTextBox.Text.Trim();
            employee.EmailAddress = EmailTextBox.Text.Trim();
            employee.Mobile = MobileNumberTextBox.Text.Trim();
            employee.Telephone = PhoneNumberTextBox.Text.Trim();
            employee.EmploymentDate = EmploymentDateDateTimePicker.Value.Date;
            employee.genderId = (GenderComboBox.SelectedIndex == -1) ? 0 : Convert.ToInt32(GenderComboBox.SelectedValue);
            employee.BranchId = (BranchComboBox.SelectedIndex == -1) ? 0 : Convert.ToInt32(BranchComboBox.SelectedValue);

            employee.Photo = (PhotoPictureBox.Image == null) ? null : ImageManipulation.GetPhoto(PhotoPictureBox);



            employee.AddressLine = AddressLinetextBox.Text.Trim();
            employee.CityId = (CityComboBox.SelectedIndex == -1) ? 0 : Convert.ToInt32(CityComboBox.SelectedValue);
            employee.DistrictId = (DistrictComboBox.SelectedIndex == -1) ? 0 : Convert.ToInt32(DistrictComboBox.SelectedValue);
            employee.JobTitled = (JobTitleComboBox.SelectedIndex == -1) ? 0 : Convert.ToInt32(JobTitleComboBox.SelectedValue);
            employee.PostalCode = PostalCodetextBox.Text.Trim();
            employee.CurrentSalary = Convert.ToDecimal( CurrentSalarytextBox.Text);
            employee.StartingSalary = Convert.ToDecimal(StartingtSalarytextBox.Text);

            employee.HasLeft = (HasLeftComboBox.Text == "Yes") ? true : false;
            employee.DateLeft =(HasLeftComboBox.Text=="Yes")? DateLeftDateTimePicker.Value.Date :(DateTime?) null;
            employee.ReasonLeftId=(ReasonLeftComboBox.SelectedIndex == -1) ? 0 : Convert.ToInt32(ReasonLeftComboBox.SelectedValue);
            employee.Comments = CommentsTextBox.Text.Trim();
            employee.CreatedBy = LoggedInUser.UserName;





            return employee;
        }

        private bool IsFormValid()
        {
            if(FullNameTextBox.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Full Name Is Required");
                FullNameTextBox.Focus();
                return false;
            }

            if (DateOfBirthTimePicker.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Date Of Birth Is Required");
                DateOfBirthTimePicker.Focus();
                return false;
            }

            if (NICNumberTextBox.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("NIC Numbe Is Required");
                NICNumberTextBox.Focus();
                return false;
            }

            if ((MobileNumberTextBox.Text.Trim() == string.Empty) && (PhoneNumberTextBox.Text.Trim() == string.Empty))
            {
                JIMessageBox.ShowErrorMessage("Mobile Or Phone Numbe Is Required");
                MobileNumberTextBox.Focus();
                return false;
            }


            if (GenderComboBox.SelectedIndex==-1)
            {
                JIMessageBox.ShowErrorMessage("Gender is Required");
               
                return false;
            }

            if (EmploymentDateDateTimePicker.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Employment date Is Required");
                EmploymentDateDateTimePicker.Focus();
                return false;
            }

            if (CityComboBox.SelectedIndex == -1)
            {
                JIMessageBox.ShowErrorMessage("City is Required");

                return false;
            }

            if (DistrictComboBox.SelectedIndex == -1)
            {
                JIMessageBox.ShowErrorMessage("Distinct is Required");

                return false;
            }

            if (AddressLinetextBox.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Address line Is Required");
                AddressLinetextBox.Focus();
                return false;
            }

            if (PostalCodetextBox.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Postal Code Is Required");
                PostalCodetextBox.Focus();
                return false;
            }

            if (JobTitleComboBox.SelectedIndex == -1)
            {
                JIMessageBox.ShowErrorMessage("Job Title  is Required");

                return false;
            }

            if (CurrentSalarytextBox.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Curent Salary Is Required");
                CurrentSalarytextBox.Focus();
                return false;
            }
            else
            {
                if (Convert.ToDecimal(  CurrentSalarytextBox.Text.Trim()) <1 )
                {
                    JIMessageBox.ShowErrorMessage("Current Salary Can't be less than or equal Zero ");
                    CurrentSalarytextBox.Focus();
                    return false;
                }
            }

            if (StartingtSalarytextBox.Text.Trim() == string.Empty)
            {
                JIMessageBox.ShowErrorMessage("Starting Salary Is Required");
                StartingtSalarytextBox.Focus();
                return false;
            }
            else
            {
                if (Convert.ToDecimal(StartingtSalarytextBox.Text.Trim()) < 1)
                {
                    JIMessageBox.ShowErrorMessage("Starting `Salary Can't be less than or equal Zero ");
                    StartingtSalarytextBox.Focus();
                    return false;
                }
            }


            if(HasLeftComboBox.Text=="Yes")
            {

                if (DateLeftDateTimePicker.Text.Trim() == string.Empty)
                {
                    JIMessageBox.ShowErrorMessage("Date Of Left Is Required");
                    DateLeftDateTimePicker.Focus();
                    return false;
                }

                if (ReasonLeftComboBox.SelectedIndex == -1)
                {
                    JIMessageBox.ShowErrorMessage("Reason Left is Required");

                    return false;
                }

                if (CommentsTextBox.Text.Trim() == string.Empty)
                {
                    JIMessageBox.ShowErrorMessage("Reson Left comment Is Required");
                    CommentsTextBox.Focus();
                    return false;
                }

            }



            return true;
        }

        private void FullNameTextBox_TextChanged(object sender, EventArgs e)
        {
            TopPanelLabel.Text = FullNameTextBox.Text;
        }

        private void HasLeftComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(HasLeftComboBox.Text=="No")
            {
                DateLeftDateTimePicker.CustomFormat = " ";
                ReasonLeftComboBox.SelectedIndex = -1;
                EnabledDisabledControls(false);
            }

            if (HasLeftComboBox.Text == "Yes")
            {


                EnabledDisabledControls(true);
            }
        }

        private void EnabledDisabledControls(bool enable)
        {
            DateLeftDateTimePicker.Enabled = enable;
            ReasonLeftComboBox.Enabled = enable;
            CommentsTextBox.Enabled = enable;
        }
    }
}
