﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JIDBFramework.Windows.WinControls
{
    public partial class JIDateTimePicker : DateTimePicker
    {
        public JIDateTimePicker()
        {
            InitializeComponent();
        }

        
        public enum DataFormat {
           
            British, // dd/MM/yyyy
            British2, // dd-MM-yyyy
            British3, // dd/MM/yy
            US, // MM/dd/yyyy
            ANSI //yyyy.MM.dd
        }

        private DataFormat dateFormat = DataFormat.British;
        public DataFormat DateFormat {
            get
            { return dateFormat; }
            set
            {
                dateFormat = value;
                if(!MakeEmpty)
                {
                    SetDateFormat();
                }
            }
        }

        private void SetDateFormat()
        {
            if(DateFormat == DataFormat.British2)
            {
                this.CustomFormat = "dd-MM-yyyy";
            }

            if (DateFormat == DataFormat.British3)
            {
                this.CustomFormat = "dd/MM/yy";
            }

            if (DateFormat == DataFormat.US)
            {
                this.CustomFormat = "MM/dd/yyyy";
            }

            if (DateFormat == DataFormat.ANSI)
            {
                this.CustomFormat = "yyyy.MM.dd";
            }
        }

        private bool makeEmplty = false;
        [Description("show tble in the foloowing formats dd-MM-yyyy")]
        public bool MakeEmpty
        {
            get
            {
                return makeEmplty;
            }
            set {
                makeEmplty =value;
                if(makeEmplty==true)
                {
                    CustomFormat = " ";
                    Format = DateTimePickerFormat.Custom;
                }
                if(makeEmplty==false)
                {
                    SetDateFormat();
                    Format = DateTimePickerFormat.Custom;
                }


            }
        }

        private void JIDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if (MakeEmpty)
            {
                SetDateFormat();
            }
        }

        private void JIDateTimePicker_KeyDown(object sender, KeyEventArgs e)
        {
            if (MakeEmpty)
            {
                if ((e.KeyCode == Keys.Back) || (e.KeyCode == Keys.Delete))
                {
                    this.CustomFormat = " ";
                }
            }
        }

        [Browsable(false)]
        public new DateTimePickerFormat Format
        {
            get { return base.Format; }
            set { base.Format = value; }
        }

        [Browsable(false)]
        public new string CustomFormat
        {
            get { return base.CustomFormat; }
            set { base.CustomFormat = value; }
        }
    }
}
